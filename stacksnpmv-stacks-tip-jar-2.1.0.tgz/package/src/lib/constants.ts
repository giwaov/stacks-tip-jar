export const CONTRACT_ADDRESS = 'SP3E0DQAHTXJHH5YT9TZCSBW013YXZB25QFDVXXWY'; export const CONTRACT_NAME = 'tip-jar-v2'; export const NETWORK = 'mainnet';
